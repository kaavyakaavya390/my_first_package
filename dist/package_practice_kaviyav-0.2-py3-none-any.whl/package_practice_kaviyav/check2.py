def call2():
	print("module2 running...")
