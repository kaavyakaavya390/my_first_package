from setuptools import setup
setup(
    name='package_practice_kaviyav',
    version='0.2',
    description='A sample Python package',
    author='Kaviya V',
    author_email='kaavyakaavya390@gmail.com',
    packages=['package_practice_kaviyav'],
)
